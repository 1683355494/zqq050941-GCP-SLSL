function[X]=fitness3(X,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G)
%% բ�ҳߴ�
L=266;
W=32.8;
%% ��ÿ������������ʩ�ͷ���
aa=zeros(1,4);
for i=1:N
    a=X(i);
    if u(a)==1&&v(a)==1
        aa(1)= aa(1)+1;
        XX{1}(aa(1))=a;
    elseif u(a)==1&&v(a)==0
        aa(2)= aa(2)+1;
        XX{2}(aa(2))=a;
    elseif u(a)==0 && v(a)==1
        aa(3)= aa(3)+1;
        XX{3}(aa(3))=a;
    elseif u(a)==0 && v(a)==0
        aa(4)= aa(4)+1;
        XX{4}(aa(4))=a;
    end
end 
%% ��һ���ڵ�һ���׶��Ͻ����ŵ�(��k=1)
% ��1
BZ1={};
b1=1;
num1=1;
x(XX{1}(1))=l(XX{1}(1));
y(XX{1}(1))=w(XX{1}(1));
BZ1{b1}(num1)=XX{1}(1);
num1=num1+1;
x(XX{1}(2))=x(XX{1}(1))+l(XX{1}(2));
y(XX{1}(2))=w(XX{1}(2));
BZ1{b1}(num1)=XX{1}(2);
%
if y(XX{1}(1))+w(XX{1}(3))<=W   
     num1=num1+1;
     BZ1{b1}(num1)=XX{1}(3);
    if y(XX{1}(2))+w(XX{1}(4))<=W
       num1=num1+1;
       BZ1{b1}(num1)=XX{1}(4);
    end
elseif y(XX{1}(2))+w(XX{1}(3))<=W 
     num1=num1+1;
     BZ1{b1}(num1)=XX{1}(3);
else
end
% ��b
while num1<aa(1)
     b1=b1+1;
     a=1;
     num1=num1+1;
     x(XX{1}(num1))=l(XX{1}(num1));
     y(XX{1}(num1))=w(XX{1}(num1));
     BZ1{b1}(a)=XX{1}(num1);
     num1=num1+1;
     a=a+1;
  if num1<=aa(1)
    x(XX{1}(num1))=x(XX{1}(num1-1))+l(XX{1}(num1));
    y(XX{1}(num1))=w(XX{1}(num1));
    BZ1{b1}(a)=XX{1}(num1);
  end
 if num1<aa(1) && y(XX{1}(num1-1))+w(XX{1}(num1+1))<=W   
    num1=num1+1;
    a=a+1;
    BZ1{b1}(a)=XX{1}(num1);
   if num1<aa(1) && y(XX{1}(num1-1))+w(XX{1}(num1+1))<=W
       num1=num1+1;
       a=a+1;
       BZ1{b1}(a)=XX{1}(num1);
   end
end
end
%% k=2Ԥ�ŵ�
BZ2={};
b2=1;
num2=1;
x(XX{2}(1))=l(XX{2}(1));
y(XX{2}(1))=w(XX{2}(1));
BZ2{b2}(num2)=XX{2}(1);
num2=num2+1;
x(XX{2}(2))=x(XX{2}(1))+l(XX{2}(2));
y(XX{2}(2))=w(XX{2}(2));
BZ2{b2}(num2)=XX{2}(2);
%
if aa(2)>2 && y(XX{2}(1))+w(XX{2}(3))<=W   
     num2=num2+1;
     BZ2{b2}(num2)=XX{2}(3);
    if aa(2)>3 && y(XX{2}(2))+w(XX{2}(4))<=W
       num2=num2+1;
       BZ2{b2}(num2)=XX{2}(4);
    end
elseif aa(2)>2 && y(XX{2}(2))+w(XX{2}(3))<=W
     num2=num2+1;
     BZ2{b2}(num2)=XX{2}(3);
end
% ��b
while num2<aa(2)
     b2=b2+1;
     a=1;
     num2=num2+1;
     x(XX{2}(num2))=l(XX{2}(num2));
     y(XX{2}(num2))=w(XX{2}(num2));
     BZ2{b2}(a)=XX{2}(num2);
     num2=num2+1;
     a=a+1;
  if num2<=aa(2)
    x(XX{2}(num2))=x(XX{2}(num2-1))+l(XX{2}(num2));
    y(XX{2}(num2))=w(XX{2}(num2));
    BZ2{b2}(a)=XX{2}(num2);
  end
 if num2<aa(2) && y(XX{2}(num2-1))+w(XX{2}(num2+1))<=W   
    num2=num2+1;
    a=a+1;
    BZ2{b2}(a)=XX{2}(num2);
   if num2<aa(2) && y(XX{2}(num2-1))+w(XX{2}(num2+1))<=W
       num2=num2+1;
       a=a+1;
       BZ2{b2}(a)=XX{2}(num2);
   end
end
end
%% �ڶ���������b�ڻ���m (m=1, 2, 3)�ļӹ�ʱ��
P=zeros(1,N);
for i=1:aa(1)
    P(XX{1}(i))=(D1(1,1)+l(XX{1}(i)))/ds(XX{1}(i));
end
for i=1:aa(2)
    P(XX{2}(i))=(D1(2,1)+l(XX{2}(i)))/ds(XX{2}(i));
end
for i=1:aa(3)
    P(XX{3}(i))=(D2(1,1)+l(XX{3}(i)))/ds(XX{3}(i));
end
for i=1:aa(4)
    P(XX{4}(i))=(D2(2,1)+l(XX{4}(i)))/ds(XX{4}(i));
end
%% k=1
P1=zeros((G(1)+5),b1);
for j=1:b1
    %P1(1,j)=sum(P(BZ1{j}(:)));
    for i=2:G(1)
    P1(i,j)=(D1(1,i)+d)/min(V1(BZ1{j}(:)));
    end
    P1(G(1)+1,j)=(D1(1,G(1)+1)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P1(G(1)+2,j)=(D1(1,G(1)+2)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P1(G(1)+3,j)=(D1(1,G(1)+3)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P1(G(1)+4,j)=(D1(1,G(1)+4)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P1(G(1)+5,j)=(D1(1,G(1)+5)+d)/min(V2(BZ1{j}(:)))+(D1(1,G(1)+6)+d)/min(V3(BZ1{j}(:)))+28.5*60;
end
%% k=2
P2=zeros((G(1)+5),b2);
for j=1:b2
    %P2(1,j)=sum(P(BZ2{j}(:)));
    for i=2:G(1)
    P2(i,j)=(D1(2,i)+d)/min(V1(BZ1{j}(:)));
    end
    P2(G(1)+1,j)=(D1(2,G(1)+1)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P2(G(1)+2,j)=(D1(2,G(1)+2)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P2(G(1)+3,j)=(D1(2,G(1)+3)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P2(G(1)+4,j)=(D1(2,G(1)+4)+d)/min(V2(BZ1{j}(:)))+20.5*60;
    P2(G(1)+5,j)=(D1(2,G(1)+5)+d)/min(V2(BZ1{j}(:)))+(D1(1,G(1)+6)+d)/min(V3(BZ1{j}(:)))+28.5*60;
end
%% k=3
P3=zeros((G(2)+1),aa(3));
for j=1:aa(3)
    %P3(1,j)=(D2(1,1)+ll(XX{3}(j)))/ds(XX{3}(j));
    for i=2:G(2)
    P3(i,j)=D2(1,i)/V1(XX{3}(j));
    end
    P3(G(2)+1,j)=D2(1,G(2)+1)/V2(XX{3}(j))+D2(1,G(2)+2)/V3(XX{3}(j))+40*60;
end
%% k=4
P4=zeros((G(2)+1),aa(4));
for j=1:aa(4)
    %P4(1,j)=(D2(2,1)+ll(XX{4}(j)))/ds(XX{4}(j));
    for i=2:G(2)
    P4(i,j)=D2(2,i)/V1(XX{4}(j));
    end
    P4(G(2)+1,j)=D2(2,G(2)+1)/V2(XX{4}(j))+D2(2,G(2)+2)/V3(XX{4}(j))+40*60;
end
%% k=1
wt1=zeros(G(1)+4,b1);
S1=zeros(b1,G(1)+5);
C1=zeros(b1,G(1)+5);
%% k=2
wt2=zeros(G(1)+4,b2);
S2=zeros(b2,G(1)+5);
C2=zeros(b2,G(1)+5);
%% k=3
wt3=zeros(G(2),aa(3));
S3=zeros(aa(3),G(2)+1);
C3=zeros(aa(3),G(2)+1);
%% k=4
wt4=zeros(G(2),aa(4));
S4=zeros(aa(4),G(2)+1);
C4=zeros(aa(4),G(2)+1);
%% ������������b�����л����ϵĿ�ʼʱ�䡢�깤ʱ���Լ��ȴ�ʱ��
% �������й����ڵ�һ�׶εĿ�ʼʱ����깤ʱ��
for k=1:4
S(XX{k}(1))=R(XX{k}(1));
C(XX{k}(1))=S(XX{k}(1))+P(XX{k}(1));
end
for k=1:4
for i=2:length(XX{k})
S(XX{k}(i))=max(R(XX{k}(i)),C(XX{k}(i-1)));
C(XX{k}(i))=S(XX{k}(i))+P(XX{k}(i));
end
end
% ����ÿ��·���ϵ�һ��բ�������н׶εĽ���ʱ��
C1(1,1)=max(C(BZ1{1}(:)));
C2(1,1)=max(C(BZ2{1}(:)));
C3(1,1)=C(XX{3}(1));
C4(1,1)=C(XX{4}(1));
for j=2:G(1)+5
S1(1,j)=C1(1,j-1);
C1(1,j)=S1(1,j)+P1(j,1);
S2(1,j)=C2(1,j-1);
C2(1,j)=S2(1,j)+P2(j,1);
end
for j=2:G(2)
S3(1,j)=C3(1,j-1);
C3(1,j)=S3(1,j)+P3(j,1);
S4(1,j)=C4(1,j-1);
C4(1,j)=S4(1,j)+P4(j,1);
end
S3(1,G(2)+1)=C3(1,G(2));
C3(1,G(2)+1)=S3(1,G(2)+1)+P3(G(2)+1,1);
S4(1,G(2)+1)=max(C4(1,G(2)),C3(1,G(2)+1));
C4(1,G(2)+1)=S4(1,G(2)+1)+P4(G(2)+1,1);
% �������д�����ͣ���������ĵȴ�ʱ��
for i=1:N
    wt(i)=S(i)-R(i);
end
%% ���㲻ͬ�׶�֮��ĵȴ�ʱ��
%% ������������
% �����һ�׶�
% k=1
for j=2:b1
    C1(j,1)=max(C(BZ1{j}(:)));
    S1(j,2)=max(C1(j,1),S1(j-1,2));
    C1(j,2)=S1(j,2)+P1(2,j);
    C1(j,1)= S1(j,2);
    for i=3:G(1)+4
    S1(j,i)=max(C1(j,i),S1(j-1,i+1)+P1(i+1,j-1));
    C1(j,i)=S1(j,i)+P1(i,j);
    C1(j,i-1)= S1(j,i);
    end
    C1(j,G(1)+4)= S1(j,G(1)+3);
    S1(j,G(1)+5)=max(C1(j,G(1)+4),S1(j-1,G(1)+5));
    C1(j,G(1)+5)=S1(j,G(1)+5)+P1(G(1)+5,j);
    % ����ȴ�ʱ��
    for i=1:G(1)+4
    if S1(j,i+1)>S1(j,i)+P1(i,j)
    wt1(i,j)=S1(j,i+1)-(S1(j,i)+P1(i,j));
    else
    wt1(i,j)=0;
    end
    end
end
%% k=2
for j=2:b2
    C2(j,1)=max(C(BZ2{j}(:)));
    S2(j,2)=max(C2(j,1),S2(j-1,2));
    C2(j,2)=S2(j,2)+P2(2,j);
    C2(j,1)= S2(j,2);
    for i=3:G(1)+4
    S2(j,i)=max(C2(j,i),S2(j-1,i+1)+P2(i+1,j-1));
    C2(j,i)=S2(j,i)+P2(i,j);
    C2(j,i-1)= S2(j,i);
    end
    C1(j,G(1)+4)= S1(j,G(1)+3);
    S2(j,G(1)+5)=max(C2(j,G(1)+4),S2(j-1,G(1)+5));
    C2(j,G(1)+5)=S2(j,G(1)+5)+P2(G(1)+5,j);
    % ����ȴ�ʱ��
    for i=1:G(1)+4
    if S2(j,i+1)>S2(j,i)+P2(i,j)
    wt2(i,j)=S2(j,i+1)-(S2(j,i)+P2(i,j));
    else
    wt2(i,j)=0;
    end
    end
end
% k=3
b3=length(XX{3});
b4=length(XX{4});
for j=2:b3
    C3(j,1)=C(XX{3}(j));
    for i=2:G(2)
    S3(j,i)=max(C3(j,i-1),S3(j-1,i));
    C3(j,i)=S3(j,i)+P3(i,j);
    C3(j,i-1)=S3(j,i);
    end
end
% k=4
for j=2:b4
    C4(j,1)=C(XX{4}(j));
    for i=2:G(2)
    S4(j,i)=max(C4(j,i-1),S4(j-1,i));
    C4(j,i)=S4(j,i)+P4(i,j);
    C4(j,i-1)=S4(j,i);
    end
end
    if b3>=b4
    for j=2:b4
    S3(j,G(2)+1)=max(C4(j,G(2)+1),C3(j-1,G(2)));
    C3(j,G(2)+1)=S3(j,G(2)+1)+P3(G(2)+1,j);
    S4(j,G(2)+1)=max(C3(j,G(2)+1),C4(j-1,G(2)));
    C4(j,G(2)+1)=S4(j,G(2)+1)+P4(G(2)+1,j);
    end
    for j=(b4+1):b3
    S3(j,G(2)+1)=max(C3(j,G(2)),C3(j-1,G(2)));
    C3(j,G(2)+1)=S3(j,G(2)+1)+P3(G(2)+1,j)+10;
    end
    end
 if b4>=b3
    for j=2:b3
    S3(j,G(2)+1)=max(C4(j,G(2)+1),C3(j-1,G(2)));
    C3(j,G(2)+1)=S3(j,G(2)+1)+P3(G(2)+1,j);
    S4(j,G(2)+1)=max(C3(j,G(2)+1),C4(j-1,G(2)));
    C4(j,G(2)+1)=S4(j,G(2)+1)+P4(G(2)+1,j);
    end
    for j=(b3+1):b4
    S4(j,G(2)+1)=max(C4(j,G(2)),C4(j-1,G(2)));
    C4(j,G(2)+1)=S4(j,G(2)+1)+P4(G(2)+1,j)+10;
    end
 end
 for j=1:b3
 for i=2:G(2)
 if S3(j,i+1)>S3(j,i)+P3(i,j)
    wt3(i,j)=S3(j,i+1)-(S3(j,i)+P3(i,j));
 else
    wt3(i,j)=0;
 end
 end
 end
for j=1:b4
 for i=2:G(2)  
 if S4(j,i+1)>S4(j,i)+P4(i,j)
    wt4(i,j)=S4(j,i+1)-(S4(j,i)+P4(i,j));
 else
    wt4(i,j)=0;
 end
 end
end
%% ���Ĳ�����Ŀ��ֵ
%% բ��������
f1=0;
for i=1:N
    if v(i)==1
        f1=f1+(l(i)*w(i))/(W*L);
    end
end
f1=(b1+b2)/f1;
%% ƽ���ȴ�ʱ��
f2=sum(sum(wt1))/b1+sum(sum(wt2))/b2+sum(sum(wt3))/b3+sum(sum(wt4))/b4+sum(wt)/N;  %ƽ���ȴ�ʱ��
f2=f2/3600;
%% �ܺ�
E1=0.5*sum(PA.*(wt))/3600; % ͣ���ܺ�
% ������ͣ���ܺ�
for i=1:b1
    bz1=BZ1{i}(:);
    m1(i)=0;
    y1(i)=0;
    for j=1:length(bz1)
    m1(i)=m1(i)+PA(bz1(j));
    y1(i)=y1(i)+PM(bz1(j));
    end
    e1(i)= 0.5*m1(i)*sum(wt1(:,i));
end
for i=1:b2
    bz2=BZ2{i}(:);
    m2(i)=0;
    y2(i)=0;
    for j=1:length(bz2)
    m2(i)=m2(i)+PA(bz2(j));
    y2(i)=y2(i)+PM(bz2(j));
    end
    e2(i)= 0.5*m2(i)*sum(wt2(:,i));
end
for i=1:b3
    e3(i)=0.5*PA(XX{3}(i))*sum(wt3(:,i));
end
for i=1:b4
    e4(i)=0.5*PA(XX{4}(i))*sum(wt4(:,i));
end
E2=(sum(e1)+sum(e2)+sum(e3)+sum(e4))/3600; 
% ��ʻ�ܺ�
for i=1:N
Y(i)=(PM(i)*0.8+2*PA(i)*0.5)*P(i);
end
for i=1:b1
p1(i)=y1(i)*0.8+2*m1(i)*0.5;
t1(i)=sum(P1(:,i))-20.5*60*4-28.5*60;
Y1(i)=p1(i)*t1(i);
end
for i=1:b2
p2(i)=y2(i)*0.8+2*m2(i)*0.5;
t2(i)=sum(P2(:,i))-20.5*60*4-28.5*60;
Y2(i)=p2(i)*t2(i);
end
for i=1:b3
    p3(i)=PM(XX{3}(i))*0.8+2*PA(XX{3}(i))*0.5;
    t3(i)=sum(P3(:,i))-40*60;
    Y3(i)=p3(i)*t3(i);
end
for i=1:b4
    p4(i)=PM(XX{4}(i))*0.8+2*PA(XX{4}(i))*0.5;
    t4(i)=sum(P4(:,i))-40*60;
    Y4(i)=p4(i)*t4(i);
end
E3=(sum(Y)+sum(Y1)+sum(Y2)+sum(Y3)+sum(Y4))/3600;
f3=E1+E2+E3;
X=[X,f1,f2,f3];
