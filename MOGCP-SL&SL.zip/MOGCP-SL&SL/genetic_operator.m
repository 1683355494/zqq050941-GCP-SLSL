function f  = genetic_operator(parent_chromosome,V)
[n,m] = size(parent_chromosome);
clear m;
p = 1;
% Flags used to set if crossover and mutation were actually performed. 
was_crossover = 0;
was_mutation = 0;

for i = 1 : n
    % With 90 % probability perform crossover
    if rand(1) < 0.5
        % Initialize the children to be null vector.
        child_1 = [];
        child_2 = [];
        % Select the first parent
        parent_1 = round(n*rand(1));
        if parent_1 < 1
            parent_1 = 1;
        end
        % Select the second parent
        parent_2 = round(n*rand(1));
        if parent_2 < 1
            parent_2 = 1;
        end
        % Make sure both the parents are not the same. 
        while parent_1== parent_2
            parent_1 = round(n*rand(1));  
            if parent_1 < 1
               parent_1 = 1;
            end
        end
        % Get the chromosome information for each randomnly selected
        % parents
%         parent_1 = parent_chromosome(parent_1,:);
%         parent_2 = parent_chromosome(parent_2,:);
        % Perform corssover for each decision variable in the chromosome.
                m1=randperm(V-2,1);
                Temp=parent_chromosome(parent_1,1:m1);
                child_1(1:m1)=parent_chromosome(parent_2,1:m1);
                child_1(m1+1:V)=parent_chromosome(parent_1,m1+1:V);
                child_2(m1+1:V)=parent_chromosome(parent_2,m1+1:V);
                child_2(1:m1)=Temp;      %���������֮ǰ��Ⱦɫ��
            for j=1:m1
              while(find(child_1(m1+1:V)==child_1(j)))     %�ҵ��ظ��ĵ㲢�滻      
                temp0=find(child_1(m1+1:V)==child_1(j));
                 child_1(j)= child_2(temp0+m1);
              end

              while(find(child_2(m1+1:V)==child_2(j)))            
                temp0=find(child_2(m1+1:V)==child_2(j));
                 child_2(j)= child_1(temp0+m1);
              end
            end
%--------------------------------------------------------------------------
        was_crossover = 1;
        was_mutation = 0;
    else
        % Select at random the parent.
        parent_3 = round(n*rand(1));
        if parent_3 < 1
            parent_3 = 1;
        end
        % Get the chromosome information for the randomnly selected parent.
        child_3 = parent_chromosome(parent_3,:);
                    m2=randperm(V,2);
                    temp1=min(m2);
                    temp2=max(m2);
                    child_3(temp1)=child_3(temp2); %Perform mutation on eact element of the selected parent.
       child_3(temp2)=parent_chromosome(parent_3,temp1);
        % Set the mutation flag
        was_mutation = 1;
        was_crossover = 0;
    end
    % Keep proper count and appropriately fill the child variable with all
    % the generated children for the particular generation.
    if was_crossover
        child(p,:) = child_1;
        child(p+1,:) = child_2;
        was_cossover = 0;
        p = p + 2;
    elseif was_mutation
        child(p,:) = child_3(:,1:V);
        was_mutation = 0;
        p = p + 1;
    end
end
f = child;
