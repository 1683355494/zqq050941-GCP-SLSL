%ǿ�Ƚ����Ļ���Paretoǰ�˵���Ӧ�ȷ������SPEA-II
function [x,y] = Strength_Pareto(x,V,M)
[N,l] = size(x);
K = ceil(sqrt(N));
% There is nothing to this assignment, used only to manipulate easily in
% MATLAB.
individual = [];
for i = 1 : N
    % Number of individuals that dominate this individual
    individual(i).n = 0;
    % Individuals which this individual dominate
    individual(i).p = [];
    for j = 1 : N
        dom_less = 0;
        dom_equal = 0;
        dom_more = 0;
        for k = 1 : M
            if (x(i,V + k) < x(j,V + k))
                dom_less = dom_less + 1;
            elseif (x(i,V + k) == x(j,V + k))
                dom_equal = dom_equal + 1;
            else
                dom_more = dom_more + 1;
            end
        end
        if dom_less == 0 & dom_equal ~= M
            individual(i).n = individual(i).n + 1;
        elseif dom_more == 0 & dom_equal ~= M
            individual(i).p = [individual(i).p j];
        end
    end   
end

    Z(:,1:M) = x(:,(V + 1):(V + M));
    SIGMA=pdist2(Z,Z,'seuclidean');
    SIGMA=sort(SIGMA);
    for i=1:N
       f(i) = individual(i).n + 1/(SIGMA(K,i)+2);
    end
    x = x;
     y=f';


