function [Z]=SPEA2()                         
Ne=20;
sizepa=[];
it=1;
t0=cputime;
xmin=0;xmax=10;
K=3;
%--------------------------------------------------------------------------
NPOP=oldpop;
EPOP=[];  Epa=[];%Initialization
%--------------------------------------------------------------------------
CPUTime=1;
while CPUTime<maxCpu %ֹͣ����Ϊ�ﵽ���������� 
twoPOP=[NPOP;EPOP];%����ϲ�
[m,nn]=size(NPOP);
Npa=zeros(m,N+K);
for i=1:m
Npa(i,:)=fitness3(NPOP(i,:),D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G);  %OVcom(NPOP,TestNO);  %���߱���+Ŀ��ֵ
% Npa(i,:)=Npa1;
end
twopa=[Npa;Epa]; %�ϲ�
[twopa, Fit] = Strength_Pareto(twopa,N,K); %fitness assignment, ��+��Ӧ��ֵ
%--------------------------------------------------------------------------
[EPOP,Epa] = APESPEA2f(twoPOP,twopa,Fit,Ne);%enviromental selection
%--------------------------------------------------------------------------
[Epa,EFit] = Strength_Pareto(Epa,N,K);

NPOP=BTSf(EPOP,EFit);%selection
mu = 10;
mum = 10;
NPOP = genetic_operator(NPOP,N); %crossover and mutation
% disp(sprintf('generation: %d',it));
it=it+1;%��������  
CPUTime=cputime-t0;      
end  %the end of iterations
Z = Epa;

