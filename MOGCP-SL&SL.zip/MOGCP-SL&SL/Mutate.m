function y=Mutate(x,V)  
yy=x;
                    m=randperm(V,2);
                    yy(m(1))=x(m(2));
                    yy(m(2))=x(m(1));
        y = yy;
end