%ȥ����ͬ��Ⱦɫ��
function P=QDXTJ(Q)
[a b]=size(Q);
c=1;
P=Q(1,:);
for i=2:a
   k=1;
   u=0;
while (k<=c)
    r=find(Q(i,:)~=P(k,:));
        if ~isempty(r)
            u=u+1;  
        end
          k=k+1;
end
if u==c
    P=[P;Q(i,:)];
end
    [c d]=size(P);
end
P;
end
            
            
    

    
    