function FF=normal(F,OV)
[pop,N]=size(F);
 for j = 1:N
     for i = 1:pop
        FF(i,j) = (F(i,j)-min(OV(:,j)))/(max(OV(:,j))-min(OV(:,j)));
     end
end
FF;
    