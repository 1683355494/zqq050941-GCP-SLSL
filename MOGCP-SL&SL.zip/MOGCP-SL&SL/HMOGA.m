function [Z]=HMOGA() 
t0=cputime;
maxgen=100;
YY0=[100000 1000000 1000000]; %��ʼ�ο���
YYmax=[0 0 0]; % ��ʼ���ֵ��
af=1.4;
bf=0.8;
Tmax=15;
r=0.1;
Pc=0.7;
Pm=0.2;
K1=3;
flj1=oldpop1(:,1:N);
for ii=1:50
flj0=flj1(ii,:);
flj00=fitness3(flj0,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G); 
flj(ii,:)=flj00;
end
for ii=1:50
oldpop0=oldpop1(ii,:);
[oldpop00, YY0, YYmax] = FREA(oldpop0,YY0,YYmax,K1,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,af,bf,G); 
oldpop(ii,:)=oldpop00;
end
gen=1;
CPUTime=1;
while CPUTime<maxCpu 
    if gen==1
        Z=flj;
    else
        Z=pareto1(newflj,Z,N); %newflj�ں���
    end
   Z=QDXTJ(Z);%ȥ��newpop�е���ͬ����
   [waiH,~]=size(Z);
 %--------------�ⲿ����ά��-----------------------------------------------
 if waiH>20
     Z=non_domination_sort_mod(Z,N,K1);
     [~,iHDE]=sort(Z(:,N+K1+2),'descend');
     Z=Z(iHDE(1:20),1:N+K1);%%�õ������ӽ������е��ⲿ��������
 end
  %------------�����Ӧ�Ⱥ���ֵ--------------------------------------------
    for j=1:popsize
        oldpopfit(j)=oldpop(j,N+K1+1);
    end
%---------------------------Ⱥ�����---------------------------------------
for j=1:2:popsize-4
          p1=oldpop(j,1:N);
          p2=oldpop(j+1,1:N);
          temp=rand;
          if Pc>temp
          [popc(j,:), popc(j+1, :)] = Crossover(p1, p2, N); %�������
          else
             popc(j, :)= p1;
             popc(j+1, :)= p2;
          end
%--------------------------------------------------------------------------      
end
 
   for k=1:popsize-4
        i = randi([1 popsize]);
        p = oldpop(i,1:N);
         temp =rand;%����һ�������
       if  Pm>temp%�������С�ڱ������ʱ��������
        popm(k, :) = Mutate(p, N);  %�������
       else
        popm(k, :)=p;  
       end
   end
       % Merge
  newpop1 = [popc
            popm];
  for ii=1:50      
  newpop11 = fitness3(newpop1(ii,1:N),D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G);
  newpop0(ii,:)=newpop11;
  end
  newpop2 = [oldpop(:,1:N+K1);newpop0];
  [newpop2,YY0,YYmax]=FC(newpop2,YY0,YYmax,K1,af,bf,N);     %FCEϵ������
    [~,index0] = sort(newpop2(:, N+K1+1),'descend');
    newpop3 = newpop2(index0(1:popsize),1:N+K1+1);%��Ӣ����
   %----------adaptive local search starting strategy----------------------
    if gen==1
        QE(gen)=Quasi_entropy(newpop3,K1,N);
        oldpop = newpop3(1:popsize,1:N+K1+1);
        newflj=newpop3(1:popsize,1:N+K1);
    else
        QE(gen)=Quasi_entropy(newpop3,K1,N);
        if QE(gen) <= 0.98*QE(1)
            S = local_search(newpop3,N,Tmax,r);
            [mm,nn]=size(S);
            for jj=1:mm
            S(jj,:)=fitness3(S(jj,:),D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G); 
            end
            newpop4=[S;newpop3];
            [newpop4,YY0,YYmax]=FC(newpop4,K1,af,bf,N);     %FCEϵ������
            oldpop = newpop4(1:popsize,1:N+K1+1);
            newflj=newpop4(1:popsize,1:N+K1); 
        else
            oldpop = newpop3(1:popsize,1:N+K1+1);
            newflj=newpop3(1:popsize,1:N+K1);
        end
     end
 %-------------------------------------------------------------------------
 %       if ~mod(gen,10)
%           fprintf('%d\n',gen);
%       end
CPUTime=cputime-t0;
end