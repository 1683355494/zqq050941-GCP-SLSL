function QE=Quasi_entropy(oldpop,K,N) 
   [m,n]=size(oldpop);
   for i=1:m
       P(i)=oldpop(i,N+K+1)/sum(oldpop(:,N+K+1));
       PP(i)=P(i)*log(P(i));
   end
   QE=-sum(PP);
end