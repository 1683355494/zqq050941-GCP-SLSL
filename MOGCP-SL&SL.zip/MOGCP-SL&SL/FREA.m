function [oldpop, YY0, YYmax] = FREA(oldpop,YY0,YYmax,K,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,af,bf,G)   %ģ�������ط���
oldpop=fitness3(oldpop,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G);
[oldpop,YY0,YYmax]=FC(oldpop,YY0,YYmax,K,af,bf,N);
end
