%ѡ�����
function myi=select(popsize,oldpopfit)
rand1=round(rand()*(popsize-1));
if rand1==0
    rand1=1;
end
if rand==popsize
    rand1=popsize-1;
end
rand2=rand1+1;
temp=oldpopfit(rand1);
myi=rand1;
for i=rand1:rand2
     if oldpopfit(i)>temp
          temp=oldpopfit(i);  % ��Ӧ��ȡ����
	       myi=i;
     end
end
end

