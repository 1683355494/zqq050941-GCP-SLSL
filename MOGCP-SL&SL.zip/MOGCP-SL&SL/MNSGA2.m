function [Z]=MNSGA2()
t0=cputime;
Pc=0.7;
Pm=0.5;
gen=1;
K=3;
chromosome=zeros(PopSize,N+K);
for i=1:PopSize
chromosome(i,:)=fitness3(chrom(i,:),D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G);
end
chromosome=non_domination_sort_mod(chromosome,N,K);
CPUTime=1;
while CPUTime<maxCpu %ֹͣ����Ϊ�ﵽ���������� 
    if gen==1
        Z=chromosome(:,1:N+K);
    else
        chromosomex=chromosome(:,1:N+K);
        Z=pareto1(chromosomex,Z,N);
    end
        Z=QDXTJ(Z);%ȥ����ͬȾɫ��
        [waiH,waiZ]=size(Z);
 %--------------�ⲿ����ά��------------------------------------------------
 if waiH>20
     Z=non_domination_sort_mod(Z,N,K);
     [b,i]=sort(Z(:,N+K+1),'ascend');
     Z=Z(i(1:20),1:N+K);%%�õ������ӽ������е��ⲿ��������
 end
%--------------------------------------------------------------------------
    pool = round(PopSize/2);
    tour = 2;
    parent_chromosome = tournament_selection(chromosome, pool, tour);
    mu =20;
    mum = 10;
 %   offspring_chromosome = genetic_operator(parent_chromosome(:,1:N),N);
chrom=parent_chromosome(:,1:N); 
%% ���㽻��     
    for i =1:2:(PopSize/2-1) 
    temp=rand;
      if Pc>temp
              m=randperm(N-1,1);
                Temp=chrom(i,1:m);
                chrom(i,1:m)=chrom(i+1,1:m);
                chrom(i+1,1:m)=Temp;      %���������֮ǰ��Ⱦɫ��
            for j=1:m
              while(find(chrom(i,m+1:N)==chrom(i,j)))     %�ҵ��ظ��ĵ㲢�滻      
                temp0=find(chrom(i,m+1:N)==chrom(i,j));
                 chrom(i,j)= chrom(i+1,temp0+m);
              end

              while(find(chrom(i+1,m+1:N)==chrom(i+1,j)))            
                temp0=find(chrom(i+1,m+1:N)==chrom(i+1,j));
                 chrom(i+1,j)= chrom(i,temp0+m);
              end
            end   
       end
   end  
%% ��ת�������
     for i=1:PopSize/2 
                temp =rand;%����һ�������
               if  Pm>temp%�������С�ڱ������ʱ��������
                   m=randperm(N,2);
                    temp1=min(m);
                    temp2=max(m);
                    chrom(i,temp1:temp2)=fliplr(chrom(i,temp1:temp2));
               end
     end 
%%
%   offspring_chromosome=LOV(offspring_chromosome(:,1:N));
    for ii=1:pool
     offspring_chromosomex=fitness3(chrom(ii,:),D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G);
     offspring_chromosomey(ii,:)=offspring_chromosomex;
    end
    [main_pop,temp] = size(chromosome);
    [offspring_pop,temp] = size(offspring_chromosomey);
    
    clear temp
    
    intermediate_chromosome(1:main_pop,1:K+N) = chromosome(:,1:K+N);
    intermediate_chromosome(main_pop + 1:main_pop + offspring_pop,1:K+N) = offspring_chromosomey;

    intermediate_chromosome =non_domination_sort_mod(intermediate_chromosome, N, K);
   
    chromosome = replace_chromosome(intermediate_chromosome, K, N, PopSize);
    chromosome=chromosome(:,1:K+N);
    chromosome=non_domination_sort_mod(chromosome, N, K);
%     if ~mod(gen,10)
%         clc
%         fprintf('%d generations completed\n',gen);
%     end
gen=gen+1;%��������  
CPUTime=cputime-t0;
end

