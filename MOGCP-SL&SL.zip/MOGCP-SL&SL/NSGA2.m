function [Z]=NSGA2()
t0=cputime;
gen=1;
K=3;
chromosome=zeros(PopSize,N+K);
for i=1:PopSize
chromosome(i,:)=fitness3(chrom(i,:),D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G);
end
chromosome=non_domination_sort_mod(chromosome,N,K);
CPUTime=1;
while CPUTime<maxCpu 
    if gen==1
        Z=chromosome(:,1:N+K);
    else
        chromosomex=chromosome(:,1:N+K);
        Z=pareto1(chromosomex,Z,N);
    end
        Z=QDXTJ(Z);%ȥ����ͬȾɫ��
        [waiH,waiZ]=size(Z);
 %--------------�ⲿ����ά��------------------------------------------------
 if waiH>10
     Z=non_domination_sort_mod(Z,N,K);
     [b,i]=sort(Z(:,N+K+1),'ascend');
     Z=Z(i(1:20),1:N+K);%%�õ������ӽ������е��ⲿ��������
 end
%--------------------------------------------------------------------------
    pool = round(PopSize/2);
    tour = 2;
    parent_chromosome = tournament_selection(chromosome, pool, tour);
    mu =10;
    mum = 10;
    offspring_chromosome = genetic_operator(parent_chromosome(:,1:N),N);
%   offspring_chromosome=LOV(offspring_chromosome(:,1:N));
    for ii=1:pool
     offspring_chromosomex=fitness3(offspring_chromosome(ii,:),D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,G);
     offspring_chromosomey(ii,:)=offspring_chromosomex;
    end
    [main_pop,temp] = size(chromosome);
    [offspring_pop,temp] = size(offspring_chromosomey);
    
    clear temp
    
    intermediate_chromosome(1:main_pop,1:K+N) = chromosome(:,1:K+N);
    intermediate_chromosome(main_pop + 1:main_pop + offspring_pop,1:K+N) = offspring_chromosomey;

    intermediate_chromosome =non_domination_sort_mod(intermediate_chromosome, N, K);
   
    chromosome = replace_chromosome(intermediate_chromosome, K, N, PopSize);
    chromosome=chromosome(:,1:K+N);
    chromosome=non_domination_sort_mod(chromosome, N, K);
%     if ~mod(gen,10)
%         clc
%         fprintf('%d generations completed\n',gen);
%     end
gen=gen+1;%��������  
CPUTime=cputime-t0;
end

