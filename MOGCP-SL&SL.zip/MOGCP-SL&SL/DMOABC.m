function [Z1]=DMOABC()
t0=cputime;
YY0=[10000 1000000 1000000]; 
YYmax=[0 0 0];
K1=3;
%%  
 TabuLength=1;
 TabuList=zeros(N);                     
 TB=5;
%% 
counter=1;   
CPUTime=1;
while CPUTime<maxCpu
    
        J=zeros(1,PopSize);
    for i=1:PopSize
        [oldpop, YY0, YYmax] = FREA(chrom(i,:),YY0,YYmax,K1,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,af,bf,G);
        J(i)=1/oldpop(N+K1+1);
        flj(i,:)=oldpop(1:N+K1);
    end
    Fit0=1./J;       
    f_avg=sum(Fit0)/PopSize;
    Tempchrom0=chrom; 
    %% 
    if counter==1
        Z1=flj;
    else
        Z1=pareto1(flj,Z1,N); 
    end
   Z1=QDXTJ(Z1);
   [waiH,~]=size(Z1);
 %-------------------------------------------
 if waiH>20
     Z1=non_domination_sort_mod(Z1,N,K1);
     [~,iHDE]=sort(Z1(:,N+K1+2),'descend');
     Z1=Z1(iHDE(1:20),1:N+K1);
 end

    %%  
   totalfit = sum(Fit0); 
        fitvalue =cumsum(Fit0); 
        for newin =1:PopSize
            fitin = 1;
            temp = rand*totalfit;
            while temp>fitvalue(fitin)
                  fitin = fitin +1;      
            end
            Tempchrom(newin,:) = chrom(fitin,:);
        end
        chrom=Tempchrom;
%% 
    for i =1:2:(PopSize-1) 
    temp=rand;
       if Pc>temp
          
          m=randperm(N-1,1);
                Temp=chrom(i,1:m);
                chrom(i,1:m)=chrom(i+1,1:m);
                chrom(i+1,1:m)=Temp;     
            for j=1:m
              while(find(chrom(i,m+1:N)==chrom(i,j)))     
                temp0=find(chrom(i,m+1:N)==chrom(i,j));
                 chrom(i,j)= chrom(i+1,temp0+m);
              end

              while(find(chrom(i+1,m+1:N)==chrom(i+1,j)))            
                temp0=find(chrom(i+1,m+1:N)==chrom(i+1,j));
                 chrom(i+1,j)= chrom(i,temp0+m);
              end
            end
              
       end
   end  
%% 
     for i=1:PopSize 
                temp =rand;
                if  Pm>temp
                   m=randperm(N,2);
                    temp1=min(m);
                    temp2=max(m);
                    chrom(i,temp1:temp2)=fliplr(chrom(i,temp1:temp2));
                end
      end 
    %% 
    for i=1:PopSize
        [oldpop, YY0, YYmax] = FREA(chrom (i,:),YY0,YYmax,K1,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,af,bf,G);
        if J(i)<(1/oldpop(N+K1+1) )
            chrom(i,:)=Tempchrom0(i,:); 
            J1(i)=J(i);
        else
            J1(i)=(1/oldpop(N+K1+1));
        end
     end
     [LL,IIndex]=sort(J1);
     XSortchrom=zeros(PopSize,N);
     for i=1:PopSize
     XSortchrom(i,:)=chrom(IIndex(i),:);   
     end
%%  
   i=1;
   A=zeros(TB,2);        
    while i<=TB       
            TT=N*rand(1,2);
            TT=ceil(TT);
            if TT(1)~=TT(2)
                A(i,1)=max(TT(1),TT(2));
                A(i,2)=min(TT(1),TT(2));
                 if i==1
                    isa=0;
                    else
                    for j=1:i-1
                        if A(i,1)==A(j,1) && A(i,2)==A(j,2)
                            isa=1;
                            break;
                        else
                            isa=0;
                        end
                    end
                end 
                if ~isa
                   i=i+1;
                else 
                end            
            else 
            end
    end
for i=1:0.1*PopSize
BSF=XSortchrom(i,:);
BestC=J1(i);
 %%  
counter0=1;   
while counter0<=5  
      a1=A(counter0,1);
      a2=A(counter0,2);
      Z=BSF; 
      Y=Z; 
       manner=unidrnd(3);
       if manner==1
        Y([a2,a1])=BSF([a1,a2]);
       else
          suiji=randperm(N/2,2);
          Min=min(suiji);
          Max=max(suiji);
          Chromnew1=BSF;
          group=BSF(Min:Max);
          Chromnew1(Min:Max)=[];
          inpos=length(Chromnew1);
          insertpos=unidrnd(inpos-1);
          Y=[(Chromnew1(1:insertpos)),group,Chromnew1(insertpos+1:end)];
       end
        [oldpop, YY0, YYmax] = FREA(Y,YY0,YYmax,K1,D1,D2,N,d,ds,V1,V2,V3,l,w,PM,PA,u,v,R,af,bf,G);
        object11=1/oldpop(N+K1+1);
%% 
    if object11<BestC     
         BestC=object11;
         BSF=Y;      
        for m=1:N
            for n=1:N
                if TabuList(m,n)~=0
                    TabuList(m,n)=TabuList(m,n)-1;      
                end
            end
        end
        TabuList(a1,a2)=TabuLength;  
    end
   counter0=counter0+1; 
end
  chrom(i,:)=BSF;
end
for i=0.4*PopSize+1:PopSize
  chrom(i,:)=XSortchrom(i,:);   
end
  CPUTime=cputime-t0;
  counter=counter+1;
end
