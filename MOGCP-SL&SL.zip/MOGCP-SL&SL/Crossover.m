function [y1,y2]=Crossover(x1,x2,N)
                m=randperm(N-1,1);
                Temp=x1(1:m);
                x1(1:m)=x2(1:m);
                x2(1:m)=Temp;      %���������֮ǰ��Ⱦɫ��
            for j=1:m
              while(find(x1(m+1:N)==x1(j)))     %�ҵ��ظ��ĵ㲢�滻      
                temp0=find(x1(m+1:N)==x1(j));
                 x1(j)= x2(temp0+m);
              end

              while(find(x2(m+1:N)==x2(j)))            
                temp0=find(x2(m+1:N)==x2(j));
                  x2(j)= x1(temp0+m);
              end
            end
%--------------------------------------------------------------------------   
    y1 = x1;
    y2 = x2; 
end