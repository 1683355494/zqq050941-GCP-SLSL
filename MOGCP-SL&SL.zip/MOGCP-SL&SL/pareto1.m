%���¶�̬pareto�⼯
function Y=pareto1(X,Y,V)
K=3;
[m,n]=size(X);
[p,q]=size(Y);
for i=1:p
    for j=1:m
        dom_less = 0;
        dom_equal = 0;
        dom_more = 0;
        for k = 1 : K
            if (X(j,V + k) < Y(i,V + k))
                dom_less = dom_less + 1;
            elseif (X(j,V + k) == Y(i,V + k))
                dom_equal = dom_equal + 1;
            else
                dom_more = dom_more + 1;
            end
        end
        if dom_less>= 2 && dom_equal ~= K
           Y=[Y;X(j,:)];
        end
    end
end
Y;
end
